--Readme document for *author*--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

*/20
- */2 Tweet dates
- */3 Tweet categories
- */3 User-written tweets
- */3 Determining activity type and distance
- */3 Graphing activities by distance
- */3 Implementing the search box
- */3 Populating the table

2. How long, in hours, did it take you to complete this assignment?



3. What online resources did you consult when completing this assignment? (list sites like StackOverflow or specific URLs for tutorials, etc.)



4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?



5. Is there anything special we need to know in order to run your code?

