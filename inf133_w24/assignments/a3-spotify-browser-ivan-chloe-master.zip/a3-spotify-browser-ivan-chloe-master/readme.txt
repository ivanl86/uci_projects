--Readme document for *author(s)*, *email(s)*, *UCI id(s)*--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

*/20
- */2 Communicating with the webserver
- */5 Spotify browser home page
- */4 Spotify browser artist page
- */3 Spotify browser album page
- */3 Spotify browser track page
- */3 Spotify browser custom page


2. How long, in hours, did it take you to complete this assignment?



3. What online resources did you consult when completing this assignment? (list specific URLs)



4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?



5. Did you add a bonus feature to your submission? If so, what is it and how should we see it?



6. Is there anything special we need to know in order to run your code?

