import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thermometer',
  standalone: true,
  imports: [],
  templateUrl: './thermometer.component.html',
  styleUrl: './thermometer.component.scss'
})

export class ThermometerComponent implements OnInit {
  //TODO: define Input fields and bind them to the template.

  constructor() { }

  ngOnInit() {
  }

}