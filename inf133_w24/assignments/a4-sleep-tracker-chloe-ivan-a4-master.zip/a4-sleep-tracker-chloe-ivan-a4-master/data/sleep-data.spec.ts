import { SleepData } from './sleep-data';

describe('SleepData', () => {
  it('should create an instance', () => {
    expect(new SleepData()).toBeTruthy();
  });
});
